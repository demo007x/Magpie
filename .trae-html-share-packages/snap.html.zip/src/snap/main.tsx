// 截屏遮罩窗（Windows 框选识图）：铺满光标所在显示器的透明置顶窗。
// 交互对位 macOS `screencapture -i`：拖拽出选区（四向自适应），Esc 取消，
// 过小选区（<4px）视为误触取消。选区完成后 invoke 回 Rust 做坐标换算与截屏。
// 遮罩变暗用 selection 的巨大 box-shadow 实现（洞外半透明、洞内清晰，
// 免去四块遮罩拼接），与 Snipaste/ShareX 同款手法。
import { useCallback, useEffect, useRef, useState } from "react";
import type { CSSProperties } from "react";
import { createRoot } from "react-dom/client";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import { getCurrentWebviewWindow } from "@tauri-apps/api/webviewWindow";

// 模块执行标记（最早的下钻点）：页面加载完成事件有、这条没有 = 模块级
// JS 错误（import/顶层代码崩溃），React 尚未挂载
invoke("ui_debug_log", { msg: "[snip] 模块脚本执行" }).catch(() => undefined);

interface Rect {
  x: number;
  y: number;
  w: number;
  h: number;
}

function normDrag(
  sx: number,
  sy: number,
  cx: number,
  cy: number
): Rect {
  return {
    x: Math.min(sx, cx),
    y: Math.min(sy, cy),
    w: Math.abs(cx - sx),
    h: Math.abs(cy - sy),
  };
}

function Overlay() {
  const [drag, setDrag] = useState<{ sx: number; sy: number; cx: number; cy: number } | null>(null);
  const done = useRef(false);

  const finish = useCallback((r: Rect | null) => {
    if (done.current) return;
    done.current = true;
    if (r && r.w >= 4 && r.h >= 4) {
      invoke("ocr_region_selected", { x: r.x, y: r.y, w: r.w, h: r.h }).catch(() =>
        invoke("ocr_region_cancel").catch(() => undefined)
      );
    } else {
      invoke("ocr_region_cancel").catch(() => undefined);
    }
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") finish(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [finish]);

  const rect = drag ? normDrag(drag.sx, drag.sy, drag.cx, drag.cy) : null;

  return (
    <div
      style={{ position: "fixed", inset: 0, cursor: "crosshair" }}
      onMouseDown={(e) => {
        if (e.button !== 0 || done.current) return;
        setDrag({ sx: e.clientX, sy: e.clientY, cx: e.clientX, cy: e.clientY });
      }}
      onMouseMove={(e) => {
        if (drag) setDrag({ ...drag, cx: e.clientX, cy: e.clientY });
      }}
      onMouseUp={() => {
        if (drag) finish(normDrag(drag.sx, drag.sy, drag.cx, drag.cy));
      }}
    >
      {/* 选区前整屏淡暗提示截屏模式（对齐 screencapture -i 的即时反馈）；
          拖拽后由选区的 box-shadow 接管变暗（洞外暗、洞内清晰） */}
      {!rect && <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.15)" }} />}
      {rect && (
        <div
          style={{
            position: "fixed",
            left: rect.x,
            top: rect.y,
            width: rect.w,
            height: rect.h,
            border: "1px solid #4f8cff",
            boxShadow: "0 0 0 100000px rgba(0, 0, 0, 0.3)",
            background: "transparent",
            pointerEvents: "none",
          }}
        />
      )}
    </div>
  );
}

// 截图胶囊遮罩（snip-frame，macOS 截图胶囊会话）：铺满框选所在屏的交互
// 遮罩窗——洞外半透明变暗、洞内清晰（巨大 box-shadow 挖洞，与 Overlay 同款
// 手法）。两个阶段同一窗无缝过渡（无闪变）：
// - 选区阶段（rect=null）：触发即整屏淡暗提示，按下拖出选区（白环实时跟随），
//   松手 ≥8px invoke snip_region_selected（静默截图后 Rust 发 snip://frame
//   切到会话模式），过小 = snip_region_cancel 整段取消
// - 会话阶段（rect 非空）：选区可拖动，页面本地渲染洞/描边跟随（60fps），
//   每次移动 invoke snip_frame_move 让 Rust 重排右下角胶囊（实时跟随）；
//   点击选区外 = 取消会话（snip_cancel）。
// 白环用外扩 box-shadow 画在矩形外侧：洞内像素不被遮罩污染，静默截图即
// 屏幕原始内容。与 Windows 框选交互窗（Overlay）共用 snap.html 入口，按
// 窗口 label 分流
function FrameSession() {
  // 会话矩形（非空 = 会话模式）；选区阶段的拖拽矩形独立存 sel
  const [rect, setRect] = useState<Rect | null>(null);
  const [sel, setSel] = useState<Rect | null>(null);
  const drag = useRef<{ sx: number; sy: number; rect: Rect } | null>(null);
  const selecting = useRef<{ sx: number; sy: number } | null>(null);
  const done = useRef(false);

  useEffect(() => {
    // 页面加载标记：日志里「遮罩窗已创建并显示」之后若没有这条，即页面
    // 加载失败（窗口在但不可见内容，全屏吞点击）
    invoke("ui_debug_log", { msg: "[snip] 遮罩页面已加载" }).catch(() => undefined);
    // 会话矩形由 snip_region_selected 后的 Rust 事件下发——此时用户已在
    // 本页面完成拖选交互，listen 早已注册，无注册竞态
    const un = listen<Rect>("snip://frame", (e) => {
      setSel(null);
      setRect(e.payload);
    });
    const onKey = (e: KeyboardEvent) => {
      // 窗口非 key 一般收不到键盘；收到 Esc（聚焦态异常时兜底）按取消处理
      if (e.key === "Escape") finishCancel();
    };
    window.addEventListener("keydown", onKey);
    return () => {
      un.then((f) => f()).catch(() => undefined);
      window.removeEventListener("keydown", onKey);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const finishCancel = useCallback(() => {
    if (done.current) return;
    done.current = true;
    invoke("snip_cancel").catch(() => undefined);
  }, []);

  const report = useCallback((r: Rect) => {
    invoke("snip_frame_move", { x: r.x, y: r.y, w: r.w, h: r.h }).catch(() => undefined);
  }, []);

  const clampRect = useCallback((r: Rect): Rect => {
    // 钳制在本屏视口内（Rust 侧同规则双保险）
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const w = Math.max(8, Math.min(r.w, vw));
    const h = Math.max(8, Math.min(r.h, vh));
    return {
      w,
      h,
      x: Math.max(0, Math.min(r.x, vw - w)),
      y: Math.max(0, Math.min(r.y, vh - h)),
    };
  }, []);

  // 拖拽中的选区矩形（起点 → 当前光标归一化，钳在本屏视口内）。
  // 注意不做 8px 最小尺寸钳制——那是会话拖动的规则；选区阶段必须保留
  // 真实尺寸让 mouseup 的过小阈值（误触取消）能生效
  const normDrag = useCallback((sx: number, sy: number, cx: number, cy: number): Rect => {
    const x = Math.min(sx, cx);
    const y = Math.min(sy, cy);
    return {
      x: Math.max(0, x),
      y: Math.max(0, y),
      w: Math.min(Math.abs(cx - sx), window.innerWidth - Math.max(0, x)),
      h: Math.min(Math.abs(cy - sy), window.innerHeight - Math.max(0, y)),
    };
  }, []);

  // 洞 = 会话矩形（会话模式）或选区拖拽矩形（选区阶段）。样式按矩形参数
  // 构造——勿在渲染期对可能为 null 的洞直接取属性（首帧 rect/sel 均为
  // null，无条件构造曾在渲染层抛 TypeError，页面全程空白，2026-11-04）
  const hole = rect ?? sel;
  const holeStyle = (h: Rect): CSSProperties => ({
    position: "fixed",
    left: h.x,
    top: h.y,
    width: h.w,
    height: h.h,
    // 白环用外扩 box-shadow 画在矩形外侧：洞内像素不被遮罩污染，静默截图
    // 即屏幕原始内容；贴浅色内容时靠外圈暗晕区分边界（Snipaste 同款），
    // 选区外的整幅变暗由最后一个 100000px shadow 承担
    boxShadow:
      "0 0 0 1.5px #ffffff, 0 0 0 2.5px rgba(0, 0, 0, 0.35), 0 0 8px rgba(0, 0, 0, 0.45), 0 0 0 100000px rgba(0, 0, 0, 0.3)",
    background: "transparent",
    cursor: rect ? "move" : "crosshair",
    pointerEvents: "none",
  });

  return (
    <div
      style={{ position: "fixed", inset: 0, cursor: rect ? "default" : "crosshair" }}
      onMouseDown={(e) => {
        if (e.button !== 0 || done.current) return;
        if (rect) {
          const inside =
            e.clientX >= rect.x &&
            e.clientX <= rect.x + rect.w &&
            e.clientY >= rect.y &&
            e.clientY <= rect.y + rect.h;
          if (inside) {
            drag.current = { sx: e.clientX, sy: e.clientY, rect };
          } else {
            finishCancel(); // 点选区外 = 取消
          }
        } else {
          selecting.current = { sx: e.clientX, sy: e.clientY };
          setSel({ x: e.clientX, y: e.clientY, w: 0, h: 0 });
        }
      }}
      onMouseMove={(e) => {
        const d = drag.current;
        if (d && rect) {
          // 会话模式：拖动选区，实时上报 Rust 重排胶囊
          const next = clampRect({
            x: d.rect.x + e.clientX - d.sx,
            y: d.rect.y + e.clientY - d.sy,
            w: d.rect.w,
            h: d.rect.h,
          });
          setRect(next);
          report(next);
          return;
        }
        const s = selecting.current;
        if (s) setSel(normDrag(s.sx, s.sy, e.clientX, e.clientY));
      }}
      onMouseUp={() => {
        if (rect) {
          const d = drag.current;
          drag.current = null;
          if (d) report(rect); // 收尾上报终值
          return;
        }
        if (!selecting.current) return;
        selecting.current = null;
        const r = sel;
        if (r && r.w >= 8 && r.h >= 8) {
          // 选区确认：静默截图 + 会话模式切换由 Rust 驱动（snip://frame 回发）
          invoke("snip_region_selected", { x: r.x, y: r.y, w: r.w, h: r.h }).catch(() =>
            invoke("snip_region_cancel").catch(() => undefined),
          );
        } else {
          // 过小选区 = 误触：整段取消
          finishCancel();
        }
      }}
    >
      {hole ? (
        <div style={holeStyle(hole)} />
      ) : (
        // 选区前整屏淡暗提示截图模式（对齐 Overlay 的即时反馈）
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.15)", pointerEvents: "none" }} />
      )}
    </div>
  );
}

// 全局错误捕获（页面诊断，2026-11-04）：webview 控制台错误不进终端/日志，
// 模块/渲染层任何未捕获异常都会表现为「隐形窗吞点击」——全部捞进日志
window.addEventListener("error", (e) => {
  invoke("ui_debug_log", {
    msg: `[snip] 页面错误：${e.message} @${e.filename}:${e.lineno}:${e.colno}`,
  }).catch(() => undefined);
});
window.addEventListener("unhandledrejection", (e) => {
  invoke("ui_debug_log", {
    msg: `[snip] 未处理的 Promise 拒绝：${String(e.reason)}`,
  }).catch(() => undefined);
});

const root = createRoot(document.getElementById("root")!);
try {
  const label = getCurrentWebviewWindow().label;
  invoke("ui_debug_log", { msg: `[snip] 窗口 label=${label}，挂载渲染` }).catch(
    () => undefined,
  );
  if (label === "snip-frame") {
    root.render(<FrameSession />);
  } else {
    root.render(<Overlay />);
  }
} catch (e) {
  invoke("ui_debug_log", { msg: `[snip] 挂载异常：${String(e)}` }).catch(
    () => undefined,
  );
}
